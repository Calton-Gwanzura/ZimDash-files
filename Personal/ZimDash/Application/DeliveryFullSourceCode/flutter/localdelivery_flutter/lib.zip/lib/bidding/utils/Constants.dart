const ORDERS_BID_COLLECTION = 'delivery_man';
const ALL_DELIVERY_MAN_IDS = 'all_delivery_man_ids';
const ACCEPTED_DELIVERY_MAN_IDS = 'accepted_delivery_man_ids';
const ORDERS_BID_COLLECTION_DOC_PREFIX = 'order_';
const ORDER_STATUS = 'status';
